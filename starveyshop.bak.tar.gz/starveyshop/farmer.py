#!/usr/bin/env python3
"""
Starvey Shop Daily Reward Auto-Claimer (Telegram Stars ⭐)
Automates:
1. Checking daily login reward status & streak progress (200-day ladder)
2. Auto-claiming daily reward (Telegram Stars, Tickets, Discounts)
3. Tracking Telegram Stars balance & tickets in real-time
4. Graceful handling of network timeouts & rate limits
"""

import os
import sys
import time
import json
import subprocess
from datetime import datetime, timezone, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
LOG_FILE = os.path.join(BASE_DIR, "farmer.log")

def log(msg):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted = f"[{now}] {msg}"
    print(formatted, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(formatted + "\n")
            f.flush()
    except Exception:
        pass

def load_config():
    if not os.path.exists(CONFIG_FILE):
        log(f"Config file not found: {CONFIG_FILE}")
        sys.exit(1)
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def call_api(cfg, endpoint, method="GET", data=None):
    cmd = [
        "curl", "-s", "--http2", "-m", "15",
        "-H", "Referer: https://starveyshop.com/",
        "-H", f"User-Agent: {cfg.get('user_agent', 'Mozilla/5.0')}",
        "-H", f"x-init-data: {cfg['init_data']}",
        f"https://starveyshop.com{endpoint}"
    ]
    if method == "POST":
        cmd.extend(["-X", "POST"])
        if data is not None:
            cmd.extend(["-H", "Content-Type: application/json", "-d", json.dumps(data)])

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        if res.returncode == 0 and res.stdout.strip():
            return json.loads(res.stdout)
        elif res.stderr:
            log(f"Curl error on {endpoint}: {res.stderr[:100]}")
    except subprocess.TimeoutExpired:
        log(f"Timeout calling {endpoint}")
    except Exception as e:
        log(f"Error calling {endpoint}: {e}")
    return None

def fetch_profile(cfg):
    return call_api(cfg, "/api/me")

def claim_daily(cfg):
    log("Mengeksekusi klaim daily reward Starvey Shop...")
    res = call_api(cfg, "/api/daily-reward/claim", method="POST")
    if res:
        # Beberapa respon error dikembalikan sebagai string langsung (misal: "gram_deposit", "already_claimed", dsb)
        if isinstance(res, str):
            if res == "gram_deposit":
                log(f"⚠️ Klaim gagal: Server membutuhkan deposit GRAM untuk melanjutkan. (Respon: gram_deposit)")
            else:
                log(f"⚠️ Klaim gagal: Respon tidak terduga dari server: {res}")
            return False, res
        if "error" in res:
            log(f"⚠️ Klaim gagal: {res.get('error')}")
            return False, res
        # Cek apakah respon mengandung kunci sukses
        if res.get("claimed") is not None or res.get("success") or res.get("stars") is not None:
            log("🎉 >> KLAIM DAILY REWARD SUKSES! <<")
            return True, res
        # Respon tidak dikenal tapi tidak ada error eksplisit
        log(f"⚠️ Respon klaim tidak terduga: {res}")
        return False, res
    return False, None

def get_seconds_until_next_reset():
    """Returns seconds until next 00:00 UTC (07:00 WIB)"""
    now_utc = datetime.now(timezone.utc)
    next_reset = (now_utc + timedelta(days=1)).replace(hour=0, minute=1, second=0, microsecond=0)
    diff = int((next_reset - now_utc).total_seconds())
    return max(60, diff)

def run_loop():
    log("=== Starvey Shop Daily Reward Auto-Claimer Started ===")

    while True:
        try:
            cfg = load_config()
            profile = fetch_profile(cfg)

            if not profile:
                log("Gagal mengambil data akun. Mencoba lagi dalam 60 detik...")
                time.sleep(60)
                continue

            username = profile.get("username", "")
            first_name = profile.get("firstName", "")
            stars = float(profile.get("starsCents", 0)) / 100.0
            tickets = int(profile.get("tickets", 0))
            rank = profile.get("rank", 0)

            daily = profile.get("dailyReward", {})
            claimed_days = int(daily.get("claimed", 0))
            total_days = int(daily.get("total", 200))
            can_claim = bool(daily.get("canClaim", False))
            next_day = daily.get("nextDay", claimed_days + 1)
            today_info = daily.get("today", {})
            r_type = today_info.get("type", "stars")
            r_val = today_info.get("stars") or today_info.get("tickets") or f"{today_info.get('percent', 0)}%"

            # Calculate next reset string
            sec_to_reset = get_seconds_until_next_reset()
            reset_time_wib = (datetime.now() + timedelta(seconds=sec_to_reset)).strftime("%H:%M:%S")

            log("==================================================")
            log(f"User          : {first_name} (@{username}) | Rank: #{rank}")
            log(f"Total Saldo   : {stars:.2f} Stars (⭐)")
            log(f"Total Tiket   : {tickets} Tickets (🎟️)")
            log(f"Streak Login  : Hari ke-{claimed_days}/{total_days}")
            log(f"Klaim Siap    : {can_claim}")
            log(f"Reward Berikut: Hari ke-{next_day} -> {r_type.upper()} ({r_val})")
            log(f"Klaim berikutnya: {reset_time_wib} WIB (~{sec_to_reset // 3600} jam {sec_to_reset % 3600 // 60} mnt)")
            log("==================================================")

            requires_deposit = False
            if can_claim:
                success, c_data = claim_daily(cfg)
                if success:
                    log(f"Reward Diklaim : +{r_val} {r_type.upper()}")
                    # Refresh profile
                    time.sleep(5)
                    profile = fetch_profile(cfg)
                    if profile:
                        stars = float(profile.get("starsCents", 0)) / 100.0
                        log(f"Saldo Baru    : {stars:.2f} Stars")
                elif "gram_deposit" in str(c_data):
                    requires_deposit = True
                    log("ℹ️ Klaim Hari ini memerlukan deposit GRAM. Melewati sampai reset besok pukul 07:00 WIB...")

            if requires_deposit:
                sleep_duration = sec_to_reset
            else:
                interval = cfg.get("check_interval_seconds", 1800)
                sleep_duration = min(interval, sec_to_reset)

            log(f"Tidur selama {sleep_duration} detik (~{sleep_duration // 3600} jam {(sleep_duration % 3600) // 60} menit)...")
            time.sleep(sleep_duration)

        except KeyboardInterrupt:
            log("Claimer dihentikan oleh pengguna.")
            break
        except Exception as e:
            log(f"Unexpected error: {e}")
            time.sleep(60)

if __name__ == "__main__":
    run_loop()
